#file KawacsConfig.py
"""Initialization of constants and .ini values.

This module will read the values set in the .ini file, to make them
available to the other modules. It also initializes a number of other
globally used constants.

NOTE ABOUT "VERSION" : The VERSION constant defines the current version
of Kawacs Linux Agent. It used in the communication with the Kawacs 
server, to determine if an auto-upgrade is needed.

NOTE ABOUT "MAC_ADDRESS" : The MAC_ADDRESS constant, which stores the
current main MAC address of the computer, is initialized in KawcsLib.py
"""

VERSION = '1.4.1'		# This will determine the current application version

import os
import re
import sys
import ConfigParser

# The following global variables will be read from the ini file
INI_FILE_NAME = 'kawacs.ini'	# The name of the ini file
CUSTOMER_ID = 0			# The ID of the customer to which the computer belongs
SOAP_URL = ''			# The URL of the SOAP server to which the reports are sent
DEBUG_LEVEL = 2			# The debugging level of information to use in the log files
PROFILE_ID = 0			# The ID of the profile to assign to the computer - 
				# used only at the first installation
TYPE_ID = 0			# The ID of the type of computer - used only at first install
REPORTED_MAC_ADDRESS = ''	# The MAC address reported to server last time (if any)
COMPUTER_ID = 0			# The ID of the computer in the KAWACS server
REMOTE_IP = ''			# The computer's public IP address, as seen by KAWACS server

BK_DIR = '/var/lib/afabackup/log'			# The location of afabackup logs directory
BK_CONFIG_FILE = '/etc/afabackup/afabackup.conf' 	# The afabackup config file

MAC_ADDRESS = ''		# The current MAC address of the computer (from the first interface)
				# The value is initialized in KawacsLib

IFCONFIG = '/sbin/ifconfig'	# The path to the ifconfig binary
UNAME = '/bin/uname'		# The path to the uname binary
TAR = '/bin/tar'		# The path to the tar binary
OMREPORT = '/usr/bin/omreport'	# The path to the omreport binary
DF = '/bin/df'			# The path to the df binary

cfg = ConfigParser.ConfigParser ()
cfg.read (INI_FILE_NAME)

# Read the settings from the ini file
if (cfg.has_option ('Reporting', 'customer_id')) : CUSTOMER_ID = cfg.getint ('Reporting', 'customer_id')
if (cfg.has_option ('Reporting', 'server_url')) : SOAP_URL = cfg.get ('Reporting', 'server_url') + '?wsdl'
if (cfg.has_option ('Reporting', 'debug_level')) : DEBUG_LEVEL = cfg.getint ('Reporting', 'debug_level')
if (cfg.has_option ('Reporting', 'profile_id')) : PROFILE_ID = cfg.getint ('Reporting', 'profile_id')
if (cfg.has_option ('Reporting', 'type_id')) : TYPE_ID = cfg.getint ('Reporting', 'type_id')
if (cfg.has_option ('Computer Data', 'reported_mac')) : REPORTED_MAC_ADDRESS = cfg.get('Computer Data', 'reported_mac')
if (cfg.has_option ('Computer Data', 'computer_id')) : COMPUTER_ID = cfg.get('Computer Data', 'computer_id')
if (cfg.has_option ('Computer Data', 'remote_ip')) : REMOTE_IP = cfg.get('Computer Data', 'remote_ip')
if (cfg.has_option ('Local Settings', 'ifconfig')) : IFCONFIG = cfg.get('Local Settings', 'ifconfig')
if (cfg.has_option ('Local Settings', 'uname')) : UNAME = cfg.get('Local Settings', 'uname')
if (cfg.has_option ('Local Settings', 'tar')) : TAR = cfg.get('Local Settings', 'tar')
if (cfg.has_option ('Local Settings', 'omreport')) : OMREPORT = cfg.get('Local Settings', 'omreport')
if (cfg.has_option ('Local Settings', 'df')) : DF = cfg.get('Local Settings', 'df')
if (cfg.has_option ('Local Settings', 'afabackup_config')) : BK_CONFIG_FILE = cfg.get('Local Settings', 'afabackup_config')


if (not os.path.exists (OMREPORT)) :
	OMREPORT = ''

def get_bk_log_dir (file_name) :
	"""Returns the afabackup log directory from the afabackup config file
	
	file_name : the afabackup config file
	"""
	
	REGEX_PARAMETER=r'\s*(?P<param>vardir)\s+(?P<value>.+)\s*'
	
	vardir = ''
	linenum=0
	file = open (BK_CONFIG_FILE)
	for line in file.readlines():
		linenum+=1
		l=line.strip()
		if not l: continue
		if l[0]=='#': continue
	
		match=re.match(REGEX_PARAMETER, l)
		if match :
			param, value=match.groups()
			if (param == 'vardir') :
				vardir = os.path.join (value, 'log')
				break
	file.close ()
	return vardir
	
# Read the config location from the afabackup config dir	
if (BK_CONFIG_FILE != '' and os.path.exists (BK_CONFIG_FILE)) :
	BK_DIR = get_bk_log_dir (BK_CONFIG_FILE)


# Some useful constants
LOGFILE_NAME = 'kawacs.log'
MAX_LOG_SIZE = 25 * 1024	# Max allowed size for the log file, in bytes
MAX_LOGS_KEEP = 4		# The maximum number of log files to keep
MSG_ERROR = 1
MSG_TRACE = 2
MSG_DEBUG = 3
DOWNLOAD_DIR = 'downloads'
DOWNLOAD_FILE_PREFIX = 'download_'
OMREPORT_DIR = 'omreport_out'
OMREPORT_OUT_FILE = 'omreport.xml'


def update_ini_setting (section, name, value) :
	"""Updates or saves a value in the ini file 
	
	The function returns 1 if the saving was OK or 0 otherwise
	
	Note that the first time something is written to the ini file,
	all comments are lost. This is the buggish behaviour of the
	ConfigParser class in Python.
	"""
	
	global INI_FILE_NAME
	ret = 0
	
	cfg = ConfigParser.ConfigParser()
	cfg.read(INI_FILE_NAME)
	
	if (not cfg.has_section (section)) : cfg.add_section (section)
	cfg.set (section, name, value)
	
	try :
		fp = open (INI_FILE_NAME, 'w')
		cfg.write (fp)
		fp.close ()
		ret = 1
	except IOError :
		ret = 0
	
	return ret