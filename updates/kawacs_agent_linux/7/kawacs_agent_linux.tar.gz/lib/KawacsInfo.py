#file KawacsInfo.py
"""Functions for collecting Kawacs monitoring items

This module implements functions for collecting data for Kawacs
monitoring items. These functions are named "collect_XXXX", where 
XXXX specifies the ID of the item for which information is collected.

The functions are called from kawacs_agent.py, depending on what
information was requested by the Kawacs server.

All the collect_XXXX functions take as parameter a MonitorItem 
object and a reference to the DOM tree built from the XML output
of "omreport system summary". Some of the functions will use
additional XML data (e.g. from "omreport storage" commands) or
the output of system commands for collecting the information.

The functions will modify the MonitorItem objects, appending
the respective values of the monitoring item fields. They return
1 if the information was collected OK and 0 if not
"""

import sys
import os
import re
import base64

from KawacsConfig import CUSTOMER_ID, SOAP_URL, DEBUG_LEVEL
from KawacsConfig import MAC_ADDRESS, REPORTED_MAC_ADDRESS, PROFILE_ID, TYPE_ID, COMPUTER_ID, REMOTE_IP
from KawacsConfig import BK_DIR
from KawacsConfig import IFCONFIG, UNAME, DF, VERSION
from KawacsConfig import LOGFILE_NAME, MAX_LOG_SIZE, MSG_ERROR, MSG_TRACE, MSG_DEBUG

from KawacsLib import do_log, get_xml_doc, LIBXML2_AVAILABLE

from xml.dom.ext.reader import Sax2
from xml.dom.NodeFilter import NodeFilter
import xml.dom.ext

if (LIBXML2_AVAILABLE) :
	import libxml2


# The list of item IDs for the processing of which libxml2 and
# omreport are needed
IDS_NEEDING_LIBXML2 = range(1002,1012)+range(1021,1044)

def get_first_text (element, name) :
	""" Returns the first text content from an XML element
	
	element : And xmlElement object (from libxml2), which contains a
	number of child elements.
	name : The name of a child element from the element passed as
	parameter.
	Returns : The text value of the child element specified by the
	name parameter, or None if theere is no element with that name.
	"""
	
	ret = None
	
	name_node_lst = element.xpathEval (name)
	if (len(name_node_lst) > 0) :
		ret = name_node_lst[0].getContent ()
	
	return ret


def collect_1001 (monitor_item, doc) :
	""" System (computer) name
	
	For safety, this information is collected using the uname tool, not from the omreport output
	"""
	global UNAME
	ret = 0
	
	system_name = os.popen(UNAME + ' -n').readline().strip()
	
	if (system_name is not None and system_name != '') :
		monitor_item.addSingleValue (system_name)
		ret = 1
	return ret
	
	
def collect_1002 (monitor_item, doc) :
	""" Collects information about the computer brand
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/SystemBIOS/Manufacturer'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		brand = elements[0].getContent ()
		if (brand is not None) :
			monitor_item.addSingleValue (brand)
			ret = 1
	return ret
	
	
def collect_1003 (monitor_item, doc) :
	""" Collects information about the computer model
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/ChassisInfo/ChassisProps1/ChassModel'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		model = elements[0].getContent ()
		if (model is not None) :
			monitor_item.addSingleValue (model)
			ret = 1
	return ret

		
def collect_1004 (monitor_item, doc) :
	""" Collects information about the computer serial number
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/ChassisInfo/ChassisProps2/ServiceTag'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		sn = elements[0].getContent ()
		if (sn is not None) :
			monitor_item.addSingleValue (sn)
			ret = 1
	return ret
	
	
def collect_1006 (monitor_item, doc) :
	""" Collects CPU information
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/ProcessorList/DevProcessor'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0
		
		while element :
			name = ''
			
			manufacturer = get_first_text (element, 'Manufacturer')
			if (manufacturer is not None) :
				name += manufacturer
			proc_type = get_first_text (element, 'ProcessorType')
			if (proc_type is not None) :
				name += ' '+proc_type
			
			monitor_item.appendItemValue ('name', name, cnt)
			
			speed = get_first_text (element, 'MaxSpeed')
			if (speed is not None) :
				monitor_item.appendItemValue ('speed', speed)
				
				speed_node = element.xpathEval ('MaxSpeed')[0]	# We are sure that the node exists, because we got the speed already
				if (speed_node.hasProp ('unit')) :
					monitor_item.appendItemValue ('speed_unit', speed_node.prop ('unit'))
			cnt = cnt+1
			element = element.next
			
		ret = 1
		
	return ret


def collect_1008 (monitor_item, doc) :
	""" Collects operating system name information
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Software/OSInfo/OSName'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		name = elements[0].getContent ()
		if (name is not None) :
			monitor_item.addSingleValue (name)
			ret = 1
	return ret

	
def collect_1009 (monitor_item, doc) :
	""" Collects information about the version of the operating system
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Software/OSInfo/OSVersion'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		version = elements[0].getContent ()
		if (version is not None) :
			monitor_item.addSingleValue (version)
			ret = 1
	return ret

	
def collect_1010 (monitor_item, doc) :
	""" Collects information about memory slots
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/MemoryArrayList/MemoryArray/MemPortConnList/PortGeneric'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			location = get_first_text (element, 'ExtName')
			monitor_item.appendItemValue ('location', location, cnt)
			
			occupied = get_first_text (element, 'IsOccupied')
			if (occupied == 'false') :
				# The slot is free
				conn_type = get_first_text (element, 'ConnectorType')
				monitor_item.appendItemValue ('type', conn_type, cnt)
				monitor_item.appendItemValue ('size', 0)
				
			else :
				# There is a memory card in this slot
				device_node = element.xpathEval ('MemoryDevice')[0]
				device_type = get_first_text (device_node, 'MemDevType')
				monitor_item.appendItemValue ('type', device_type)
				device_size = float (get_first_text (device_node, 'SizeMB')) * 1024 * 1024
				monitor_item.appendItemValue ('size', device_size);
			
			cnt = cnt+1
			element = element.next
			
		ret = 1
		
	return ret

	
def collect_1011 (monitor_item, doc) :
	""" Collects memory size information
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/MemoryInfo'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		# We know that in fact there is only one MemoryInfo element, 
		# so we won't loop through the list
		element = elements[0]
		
		total_size = float (get_first_text (element, 'TotalPhysMemorySizeMB')) * 1024 * 1024
		monitor_item.appendItemValue ('total', total_size)
		free_size = float (get_first_text (element, 'AvailPhysMemorySizeMB')) * 1024 * 1024
		monitor_item.appendItemValue ('free', free_size)
		
		ret = 1
		
	return ret

	
def collect_1013 (monitor_item, doc) :
	""" Collects information about partitions
	
	The information is collected from the output of 'df' 
	"""
	global DF

	ret = 0
	partitions = os.popen (DF+ ' -lT --no-sync').read()
	all_partitions = re.findall ('(\/[^\s]+)\s*([^\s]+)\s*([0-9]+)\s*([0-9]+)\s*([0-9]+)\s*([0-9]+)\%\s*(.*)', partitions)
	
	if (len(all_partitions) > 0) :
		cnt = 0
		for partition in all_partitions :
			size = float(partition[2]) * 1024	# Using float(), because int() gives problems with SOAP
			free = float(partition[4]) * 1024
			monitor_item.appendItemValue ('unc', partition[6], cnt)
			monitor_item.appendItemValue ('type', partition[1])
			monitor_item.appendItemValue ('volume', partition[0])
			monitor_item.appendItemValue ('size', size)
			monitor_item.appendItemValue ('free', free)
			cnt+= 1
		ret = 1
	
	return ret
	
	
def collect_1021 (monitor_item, doc) :
	""" Collects information about network cards
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Network/NICList/NICCard'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			name = get_first_text (element, 'Description')
			monitor_item.appendItemValue ('name', name, cnt)
			
			monitor_item.appendItemValue ('mac_address', get_first_text (element, 'CurrentMACAddr'))
			monitor_item.appendItemValue ('ip_address', get_first_text (element, 'IPAddress'))
			monitor_item.appendItemValue ('dhcp', get_first_text (element, 'DHCPServer'))
			monitor_item.appendItemValue ('gateway', get_first_text (element, 'DefaultGateway'))
			
			cnt = cnt+1
			element = element.next
			
		ret = 1
		
	return ret
	
	
def collect_1033 (monitor_item, doc) :
	""" Collects information about the system time
	"""
	
	ret = 0
	path = '/OMA/OMA/System/SystemInfo/SystemTime'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		system_time = elements[0].getContent ()
 		if (system_time is not None) :
			monitor_item.addSingleValue (system_time)
			ret = 1
	return ret
	
	
def collect_1034 (monitor_item, doc) :
	""" Collects information about the system boot time
	"""
	
	ret = 0
	path = '/OMA/OMA/System/SystemInfo/SystemBootupTime'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		boot_time = elements[0].getContent ()
 		if (boot_time is not None) :
			monitor_item.addSingleValue (boot_time)
			ret = 1
	return ret
	
	
def collect_1035 (monitor_item, doc) :
	""" Collects information about the chassis lock
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/ChassisInfo/ChassisProps1/ChassLockPresent'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		lock = elements[0].getContent ()
 		if (lock is not None) :
			monitor_item.addSingleValue (lock)
			ret = 1
	return ret
	
	
def collect_1036 (monitor_item, doc) :
	""" Collects information about the chassis asset tag
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/ChassisInfo/ChassisProps2/AssetTag'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		tag = elements[0].getContent ()
 		if (tag is not None) :
			monitor_item.addSingleValue (tag)
			ret = 1
	return ret
	
	
def collect_1037 (monitor_item, doc) :
	""" Collects information about the BIOS
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/SystemBIOS'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		# We know that in fact there is only one MemoryInfo element, 
		# so we won't loop through the list
		element = elements[0]
		
		monitor_item.appendItemValue ('version', get_first_text (element, 'Version'))
		monitor_item.appendItemValue ('release_date', get_first_text (element, 'ReleaseDate'))
		
		ret = 1

	return ret
	
	
def collect_1038 (monitor_item, doc) :
	""" Collects information about firmware
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/FirmwareList/Firmware'
	elements = doc.xpathEval (path)

	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			name = get_first_text (element, 'FWText')
			monitor_item.appendItemValue ('name', name, cnt)
			version = get_first_text (element, 'FWVersion')
			monitor_item.appendItemValue ('version', version)
			
			cnt = cnt+1
			element = element.next
			
		ret = 1
		
	return ret
	
	
def collect_1039 (monitor_item, doc) :
	""" Collects information about the DRSC system
	"""
	
	ret = 0
	path = '/OMA/OMA/DRSCSummaryObj'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		element = elements[0]
		
		product = get_first_text (element, 'DRSIdentificationObj/ProductInfo')
		monitor_item.appendItemValue ('product', product)
		version = get_first_text (element, 'DRSIdentificationObj/VersionInfo')
		monitor_item.appendItemValue ('version', version)
		ip_address = get_first_text (element, 'LanNetworkingObj/IPAddress')
		monitor_item.appendItemValue ('ip_address', ip_address)
		ip_subnet = get_first_text (element, 'LanNetworkingObj/SubnetMask')
		monitor_item.appendItemValue ('ip_subnet', ip_subnet)
		ip_gateway = get_first_text (element, 'LanNetworkingObj/Gateway')
		monitor_item.appendItemValue ('ip_gateway', ip_gateway)
		pcmcia_card = get_first_text (element, 'DRSIdentificationObj/PcmciaInfo')
		monitor_item.appendItemValue ('pcmcia_card', pcmcia_card)
		
		ret = 1
		
	return ret
	
	
def collect_1040 (monitor_item, doc) :
	""" Collects information about the PCI slots
	"""
	
	ret = 0
	path = '/OMA/OMA/ChassisList/Chassis/Hardware/SlotsList/Slot'
	elements = doc.xpathEval (path)
	
	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			slot_type = get_first_text (element, 'Type')
			monitor_item.appendItemValue ('type', slot_type, cnt)
			slot_length = get_first_text (element, 'Length')
			monitor_item.appendItemValue ('length', slot_length)
			ext_name = get_first_text (element, 'ExtName')
			monitor_item.appendItemValue ('ext_name', ext_name)
			hot_plug = get_first_text (element, 'IsHotPlugCapable')
			if (hot_plug == 'true') : hot_plug = 'Yes'
			else : hot_plug = 'No'
			monitor_item.appendItemValue ('hot_plug', hot_plug)
			
			voltage = ''
			if (get_first_text (element, 'IsVolt5') == 'true') : voltage = '5 V'
			if (get_first_text (element, 'IsVolt33') == 'true') : voltage = '3.3 V'
			monitor_item.appendItemValue ('voltage', voltage)
			
			slot_speed_node = element.xpathEval ('HotPlugSystemSlot/SlotSpeed')
			if (len(slot_speed_node) > 0) :
				slot_speed_node = slot_speed_node[0]
				slot_speed = slot_speed_node.getContent ()
				slot_speed = slot_speed + ' ' + slot_speed_node.prop ('unit')
				monitor_item.appendItemValue ('slot_speed', slot_speed)
			
			data_bus_width = get_first_text (element, 'SlotDevice/DataBusWidth')
			if (data_bus_width is not None) :
				# There is a card in this slot
				monitor_item.appendItemValue ('used', 'Yes')
				monitor_item.appendItemValue ('data_bus_width', data_bus_width)
				
				device_manufacturer = get_first_text (element, 'SlotDevice/Manufacturer')
				monitor_item.appendItemValue ('device_manufacturer', device_manufacturer)
				device_name = get_first_text (element, 'SlotDevice/DeviceDesc')
				monitor_item.appendItemValue ('device_name', device_name)
				
				adapter_speed_node = element.xpathEval ('HotPlugSystemSlot/AdapterSpeed')
				if (len(adapter_speed_node) > 0) :
					adapter_speed_node = adapter_speed_node[0]
					adapter_speed = adapter_speed_node.getContent ()
					adapter_speed = adapter_speed + ' ' + adapter_speed_node.prop ('unit')
					monitor_item.appendItemValue ('adapter_speed', adapter_speed)
					
				is_faulty = get_first_text (element, 'SlotDevice/IsAdptFault')
				if (is_faulty is not None) :
					if (is_faulty == 'true') : is_faulty = 'Yes'
					else : is_faulty = 'No'
					monitor_item.appendItemValue ('is_faulty', is_faulty)

			else :
				# There is no card in the slot
				monitor_item.appendItemValue ('used', 'No')
			
			cnt = cnt+1
			element = element.next
			
		ret = 1
		
	return ret

	
def collect_1041 (monitor_item, doc) :
	""" Collects information about the storage controllers.
	
	The information is fetched from the "omreport storage controllers"
	"""
	
	ret = 0
	
	doc_controllers = get_xml_doc ('storage controller')
	path = '/OMA/Controllers/DCStorageObject'
	elements = doc_controllers.xpathEval (path)
	
	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			if (not element.isText()) :
				controller_id = get_first_text (element, 'Nexus')
				controller_id = controller_id[1:]
				monitor_item.appendItemValue ('id', controller_id, cnt)
				
				monitor_item.appendItemValue ('status', get_first_text (element, 'ObjStatus'))
				monitor_item.appendItemValue ('name', get_first_text (element, 'Name'))
				monitor_item.appendItemValue ('slot_id', get_first_text (element, 'PCISlot'))
				monitor_item.appendItemValue ('firmware_version', get_first_text (element, 'FirmwareVer'))
				monitor_item.appendItemValue ('channels', get_first_text (element, 'Channels'))
				
				cnt = cnt+1
			element = element.get_next ()
			
		ret = 1
		
	return ret

	
def collect_1042 (monitor_item, doc) :
	""" Collects information about the storage virtual disks.
	
	The information is fetched from "omreport storage vdisk"
	"""
	
	ret = 0
	
	doc_controllers = get_xml_doc ('storage vdisk')
	path = '/OMA/VirtualDisks/DCStorageObject'
	elements = doc_controllers.xpathEval (path)
	
	if (len(elements) > 0) :
		element = elements[0]
		cnt = 0

		while element :
			if (not element.isText()) :
				vdisk_id = get_first_text (element, 'GlobalNo')
				monitor_item.appendItemValue ('id', vdisk_id, cnt)
				
				monitor_item.appendItemValue ('status', get_first_text (element, 'ObjStatus'))
				monitor_item.appendItemValue ('name', get_first_text (element, 'Name'))
				monitor_item.appendItemValue ('layout', get_first_text (element, 'Layout'))
				monitor_item.appendItemValue ('size', get_first_text (element, 'Length'))
				monitor_item.appendItemValue ('device_name', get_first_text (element, 'DeviceName'))
				monitor_item.appendItemValue ('controller_id', get_first_text (element, 'ControllerNum'))
				
				cnt = cnt+1
			element = element.get_next ()
			
		ret = 1
		
	return ret

	
def collect_1043 (monitor_item, doc) :
	""" Collects information about the phisycal disks
	
	The information is fetched from "omreport storage adisk",
	by looping over the available controllers.
	"""
	
	ret = 0
	
	doc_controllers = get_xml_doc ('storage controller')
	path = '/OMA/Controllers/DCStorageObject'
	elements_controllers = doc_controllers.xpathEval (path)
	
	if (len(elements_controllers) > 0) :
		element_controller = elements_controllers[0]
		cnt = 0

		while element_controller :
			if (not element_controller.isText()) :
				# Get the disks from this controller
				controller_id = get_first_text (element_controller, 'Nexus')
				controller_id = controller_id[1:]

				doc_disks = get_xml_doc ('storage adisk controller=' + controller_id)
				path = '/OMA/ArrayDisks/DCStorageObject'
				elements = doc_disks.xpathEval (path)
				
				if (len(elements) > 0) :
					element = elements[0]
					
					while element :
						if (not element.isText()) :
							disk_id = controller_id + ':'
							disk_id = disk_id + get_first_text (element, 'TargetID')
							monitor_item.appendItemValue ('id', disk_id, cnt)
						
							monitor_item.appendItemValue ('status', get_first_text (element, 'ObjStatus'))
							monitor_item.appendItemValue ('state', get_first_text (element, 'ObjState'))
							monitor_item.appendItemValue ('size', get_first_text (element, 'Length'))
							monitor_item.appendItemValue ('used_space', get_first_text (element, 'UsedSpace'))
							monitor_item.appendItemValue ('manufacturer', get_first_text (element, 'Vendor'))
							monitor_item.appendItemValue ('model', get_first_text (element, 'ProductID'))
							monitor_item.appendItemValue ('revision', get_first_text (element, 'Revision'))
							
							
							cnt = cnt+1
						element = element.next
				
			element_controller = element_controller.next
			
		ret = 1
		
	return ret

	
def read_bk_info (filename) :
	""" Reads the backup information from filename.
	
	Returns a dictionary with the key/value pairs read from the file
	"""
	info = {}
	try:
		file=open(filename, 'r')
		for line in file:
			if line and line[0]=='\0': break
			lst=line.split('=', 1)
			if len(lst)<2:
				continue
			parameter, value = lst
			value = str(value).strip()
			parameter = str(parameter).strip()
			info[parameter]=value
			
		file.close ()
		
	except :
		info = {}
		
	info.setdefault('count', '0')
	info.setdefault('name', '')
	info.setdefault('status', '')
	
	return info
	
	
def get_bkdir_date (bk_dir) :
	"""Converts an afabackup directory name into a date string
	"""
	
	ret = bk_dir[0:2]+'-'+bk_dir[2:4]+'-'+bk_dir[4:6]+' '
	ret+= bk_dir[7:9]+':'+bk_dir[9:11]+':'+bk_dir[11:13]
	return ret

	
def get_last_good_bk (main_bk_dir) :
	"""Reports the date of the last known good backup
	"""
	
	ret = None
	
	bk_dirs = os.listdir(main_bk_dir)
	if (len(bk_dirs) > 0) :
		bk_dirs.sort ()
		bk_dirs.reverse ()
		
		last_good_bk = None
		for bk_dir in bk_dirs :
			bk_info = read_bk_info (os.path.join (main_bk_dir, bk_dir, 'info'))
			if (bk_info['status'] == 'success' or bk_info['status'] == 'info') :
				# This was a good backup
				last_good_bk = bk_dir
				break
				
		if (last_good_bk is not None) :
			ret = get_bkdir_date (last_good_bk)
	
	return ret
    
	
def collect_1044 (monitor_item, doc) :
	"""Collects information about the last backup
	
	It will send a report about the last backup reported. It doesn't matter
	if the same backup was already reported, the Kawacs server will decide if 
	the value is new or not.
	"""
	
	global BK_DIR
	ret = 0
	
	if (BK_DIR != '' and os.path.exists(BK_DIR) and os.path.isdir(BK_DIR)) :
		report_bk_dir = ''
		for dname in os.listdir(BK_DIR) :
			if (report_bk_dir < dname and os.path.exists(os.path.join (BK_DIR, dname, 'info'))) :
				report_bk_dir = dname
		
		if (report_bk_dir != '') :
			# Sending report about the last backup performed
			bk_info = read_bk_info (os.path.join (BK_DIR, report_bk_dir, 'info'))
			
			if (bk_info is not None) :
				bk_info['date'] = get_bkdir_date (report_bk_dir)
				bk_info['last_good_backup'] = get_last_good_bk (BK_DIR)
				monitor_item.appendItemValues (bk_info)
	
				# Add the log files too, if they exist
				reporting_logs = {'summary_log':'summary.log', 'mail_log':'mail.log'}
				for (field, logfile_name) in reporting_logs.iteritems() :
					logfile_name = os.path.join (BK_DIR, report_bk_dir, logfile_name)
					try :
						if (os.path.exists (logfile_name)) :
							full_log = open (logfile_name, 'r').read ()
							full_log = base64.encodestring(full_log)
							monitor_item.appendItemValue (field, full_log)
					except :
						continue
				ret = 1

	return ret
