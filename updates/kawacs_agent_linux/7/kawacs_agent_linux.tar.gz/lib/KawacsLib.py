#file KawacsLib.py
"""Implements helper functions and classes for Kawacs Agent

The implemented classes are:

- Computer: holds information about the computer and implements
  methods for communicating with the Kawacs server.
  
- MonitorItem and MonitorItemValue: classes used for the encapsulation
  of the collected information into an organized manner.

"""

import sys
import os
import re
from SOAPpy import WSDL     
from time import localtime, strftime

from xml.dom.ext.reader import Sax2
from xml.dom.NodeFilter import NodeFilter
import xml.dom.ext

from KawacsConfig import update_ini_setting
from KawacsConfig import CUSTOMER_ID, SOAP_URL, DEBUG_LEVEL
from KawacsConfig import MAC_ADDRESS, REPORTED_MAC_ADDRESS, PROFILE_ID, TYPE_ID, COMPUTER_ID, REMOTE_IP
from KawacsConfig import VERSION, IFCONFIG, OMREPORT
from KawacsConfig import LOGFILE_NAME, MAX_LOG_SIZE, MAX_LOGS_KEEP
from KawacsConfig import OMREPORT_DIR, OMREPORT_OUT_FILE, MSG_ERROR, MSG_TRACE, MSG_DEBUG

LIBXML2_AVAILABLE = 0
try :
	import libxml2
	LIBXML2_AVAILABLE = 1
except :
	LIBXML2_AVAILABLE = 0

	
def get_current_mac () :
	"""Returns the current MAC address of the computer
	"""
	global IFCONFIG
	mac = os.popen(IFCONFIG).read()
	all_addresses = re.findall ('HWaddr ([0-9A-Z:]*)', mac)
	if (len(all_addresses) > 0) : mac = all_addresses[0]
	else : mac = ''
	
	return mac

# Set now the MAC address to be available for all modules
MAC_ADDRESS = get_current_mac ()


def do_log (message, level = MSG_TRACE) :
	"""Records information to the log file
	
	message : the actual message to add 
	level : the importance level of the message (MSG_ERROR, MSG_TRACE, MSG_DEBUG)
	
	Returns 0 if there was an error writing to the file or 1 if not
	"""
	ret = 1
	if (level <= DEBUG_LEVEL) :
		if (level == MSG_ERROR) : message = '[ERROR] '+message
		date = strftime('%d %b %Y %H:%M:%S', localtime())
		
		message = '['+date+'] '+message
		try :
			fp = open (LOGFILE_NAME, 'a')
			fp.write (message+'\n')
			fp.close ()
			ret = 0
		except IOError :
			ret = 1
	return ret


def check_log_rotation () :
	"""Rotates the log file if it has exceeded the max allowed size
	"""
	global LOGFILE_NAME, MAX_LOG_SIZE, MAX_LOGS_KEEP
	ret = 0
	if (os.path.exists (LOGFILE_NAME)) :
		try:
			if (os.path.getsize (LOGFILE_NAME) > MAX_LOG_SIZE) :
				
				if (os.path.exists (LOGFILE_NAME+'.'+str(MAX_LOGS_KEEP))) :
					os.unlink (LOGFILE_NAME+'.'+str(MAX_LOGS_KEEP))
				for i in range (MAX_LOGS_KEEP-1, 0, -1) :
					if (os.path.exists (LOGFILE_NAME+'.'+str(i))) :
						os.rename (LOGFILE_NAME+'.'+str(i), LOGFILE_NAME+'.'+str(i+1))
				
				os.rename (LOGFILE_NAME, LOGFILE_NAME+'.1')
			
			ret = 1
		except IOError :
			ret = 0
	else :
		ret = 1
	return ret


def clear_dir_cont (args, dir_name, names) :
	"""Used with os.path.walk() to recursively empty a directory
	"""
	
	for name in names :
		if (os.path.isdir (dir_name+'/'+name)) :
			os.path.walk (dir_name+'/'+name, clear_dir_cont, args)
			os.rmdir (dir_name+'/'+name)
		else :
			os.unlink (dir_name+'/'+name)
	

def clear_dir (dir_name) :
	"""Clears all contents of a directory, or creates it if it doesn't exist
	"""
	
	ret = 0
	
	try :
		if (os.path.exists (dir_name)) :
			if (os.path.isdir (dir_name)) :
				os.path.walk(dir_name, clear_dir_cont, None)
			else :
				os.unlink (dir_name)
				os.mkdir (dir_name)
		else :
			os.mkdir (dir_name)
		ret = 1
	except :
		do_log ('Error clearing directory '+dir_name+': '+str(sys.exc_info()[0])+' : '+str(sys.exc_info()[1]), MSG_ERROR)
	
	return ret
	

def get_xml_doc (param = 'system summary') :
	"""Returns a DOM object tree (libxml2) with the output of omreport
	
	param : The parameters to pass to omreport, if the caller needs
	some other output than the default "omreport system summary"
	"""
	
	global OMREPORT, OMREPORT_DIR, OMREPORT_OUT_FILE, LIBXML2_AVAILABLE
	doc = None
	if (LIBXML2_AVAILABLE and OMREPORT != '') :
		clear_dir (OMREPORT_DIR)
		
		try :
			xml = os.popen(OMREPORT + ' ' +param + ' -fmt xml').read ()
			fw = open (OMREPORT_DIR+'/'+OMREPORT_OUT_FILE, 'w')
			fw.write (xml)
			fw.close ()
			
			doc = libxml2.parseFile (OMREPORT_DIR+'/'+OMREPORT_OUT_FILE)
		except :
			do_log ('Error collecting XML info: '+str(sys.exc_info()[0])+' : '+str(sys.exc_info()[1]), MSG_ERROR)
	else :
		do_log ('Libxml2 is not available', MSG_ERROR)

	return doc


class Computer :
	"""Information about computer and communication methods 
	
	This class is used for storing information about the computer
	and for implementing communication with the Kawacs server.
	
	Note that by "computer information" we are referring to
	computer identification data (e.g. customer ID, current and
	last reported MAC), not to collected monitor items data.
	"""

	customer_id = ''		# The ID of the customer
	mac_address = ''		# Current MAC address
	reported_mac_address = ''	# The MAC address reported to
					# the Kawacs server on last contact
	profile_id = 0			# The ID of the monitor profile
					# to use - for new computers 
	type_id = 0			# The ID of the computer type
					# to user - for new computers
	version_agent = ''		# The version of Kawacs Agent,
					# to be used in checking for
					# updates from the server
	request_full_update = 0		# Pass to the Kawacs server a
					# request to update all the
					# items from the assigned profile
	
					
	def __init__ (self, customer_id=CUSTOMER_ID, mac_address=MAC_ADDRESS, reported_mac_address=REPORTED_MAC_ADDRESS, \
	version=VERSION, profile_id=PROFILE_ID, type_id=TYPE_ID) :
		"""Constructor. Optionally initializes the object attributes
		
		If the attributes are not passed as arguments to the constructor, they
		will be initialized from the ini file values.
		"""
		self.customer_id = customer_id
		self.mac_address = mac_address
		self.reported_mac_address = reported_mac_address
		self.version = version
		self.profile_id = profile_id
		self.type_id = type_id
		

	def getNeededInfo (self, full_update = 0, show_debug = 0) :
		"""Gets the list of items that need reporting
		
		full_update : send a request to the server to do a full update
		
		The method connects to the Kawacs server in order to
		obtain the list of monitor items that the server needs
		to be reported.
		""" 
		global SOAP_URL
		response = None
		
		if (SOAP_URL != '') :
			# Compose the computer identifcation data to be sent over SOAP
			computer_info = {'customer_id':self.customer_id, 'version_linux_agent':self.version}
			if (self.reported_mac_address != self.mac_address) :
				computer_info['new_mac_address'] = self.mac_address
				if (self.reported_mac_address != '') :
					computer_info['mac_address'] = self.reported_mac_address
				else :
					computer_info['mac_address'] = self.mac_address
			else :
				computer_info['mac_address'] = self.reported_mac_address
			if (self.profile_id > 0) : computer_info['profile_id'] = self.profile_id
			if (self.type_id > 0) : computer_info['type_id'] = self.type_id
				
			do_log ('Contacting server to get info; customer ID: '+str(computer_info['customer_id'])+', MAC address: '+computer_info['mac_address'], MSG_TRACE)
			do_log ('SOAP URL: '+SOAP_URL)
		
			if (computer_info['mac_address'] != '') :
				if (full_update == 1) : 
					computer_info['request_full_update'] = 'yes'
				
				if (show_debug) :
					print "Sent computer info:"
					print computer_info
				
				try :
					server = WSDL.Proxy (SOAP_URL)    
					response = server.getNeededInfo (computer_info)
				finally :
					if (response is not None) :
						response = response._asdict ()	# Dictionaries are easier to manipulate
						
						if (show_debug) :
							print "Received response:"
							print response
						
						# Update the MAC in the ini file if needed
						if (response.has_key ('reported_mac') and response['reported_mac'] is not None and response['reported_mac'] != '') :
							updated = update_ini_setting ('Computer Data', 'reported_mac', response['reported_mac'])
							if (updated == 0) :
								do_log ('Failed updating the reported MAC in the ini file', MSG_ERROR)
								
						# Save in the ini file the ID of the computer as known by Kawacs server
						if (response.has_key ('computer_id') and response['computer_id'] is not None and response['computer_id'] != '') :
							updated = update_ini_setting ('Computer Data', 'computer_id', response['computer_id'])
							if (updated == 0) :
								do_log ('Failed updating the computer ID in the ini file', MSG_ERROR)
								
						# Save in the ini file the remote IP as seen by Kawacs server
						if (response.has_key ('remote_ip') and response['remote_ip'] is not None and response['remote_ip'] != '') :
							updated = update_ini_setting ('Computer Data', 'remote_ip', response['remote_ip'])
							if (updated == 0) :
								do_log ('Failed updating the remote ID in the ini file', MSG_ERROR)
								
			else:
				do_log ('Can\'t connect to server, MAC address is unknown', MSG_ERROR)
		else :
			do_log ('The URL of the SOAP server has not been defined', MSG_ERROR)
		
		return response
		
	
	def sendCollectedData (self, data, show_debug = 0) :
		"""Sends the collected info to the Kawacs server
		
		data : array of MonitorItem objects to be sent to the server
		"""
		global SOAP_URL
		response = None
		
		if (SOAP_URL != '') :
			# Compose the computer identifcation data to be sent over SOAP
			computer_info = {'customer_id':self.customer_id}
			if (self.reported_mac_address != self.mac_address) :
				if (self.reported_mac_address != '') :
					computer_info['mac_address'] = self.reported_mac_address
				else :
					computer_info['mac_address'] = self.mac_address
			else :
				computer_info['mac_address'] = self.reported_mac_address

			do_log ('Contacting server to send data; customer ID: '+str(computer_info['customer_id'])+', MAC address: '+computer_info['mac_address'], MSG_TRACE)
			do_log ('SOAP URL: '+SOAP_URL)
				
			if (computer_info['mac_address'] != '') :
				try :
					server = WSDL.Proxy (SOAP_URL)    
					response = server.sendComputerData (computer_info, data)
				finally :
					if (response is not None) :
						# Communication was OK
						do_log ('Computer data sent OK', MSG_TRACE)
						if (show_debug) :
							print 'Computer data sent OK, response was: '
							print response
			else:
				do_log ('Can\'t send data to server, MAC address is unknown', MSG_ERROR)
		else :
			do_log ('The URL of the SOAP server has not been defined', MSG_ERROR)
		
		return response
	

class MonitorItemValue :
	"""Represents a valut included in a MonitorItem object
	"""
	field_names = []
	field_values = []
	
	def __init__ (self, name = '', value = '') :
		self.field_names = []
		self.field_values = []
		if (name != '' or value != '') :
			self.field_names.append (name)
			self.field_values.append (value)
	
	def addItemValue (self, name, value) :
		self.field_names.append (name)
		self.field_values.append (value)
	

class MonitorItem :
	"""Represents a monitoring item object 
	"""
	id = None		# The ID of the monitoring item
	value = []		# Array of MonitoringItemValue objects
	
	def __init__ (self, id) :
		self.id = id
		self.value = []
		
		
	def addSingleValue (self, val) :
		"""Sets the value for non-structure monitoring items
		"""
		self.value.append (MonitorItemValue ('', val))

		
	def appendItemValue (self, name, val, pos = None) :
		"""Appends item values for structure monitor items
		
		name : The name of the field to add
		val : The field value
		pos : The array index on which to add the value, for multi-value
		      items. If not specified, then the last element from the array is used.
		"""
		if (pos is None) : 
			# If no position specified, use the last position
			if (len (self.value) <= 0) : self.value.append (MonitorItemValue ()) 
			pos = len (self.value) - 1
		else :
			# Make sure there are enough elements in the list
			while (pos >= len (self.value)) :  self.value.append (MonitorItemValue ())
		
		self.value[pos].addItemValue (name, val)
		
		
	def appendItemValues (self, values, pos = None) :
		"""Appends a number of item values to the monitoring item
		
		values : a dictionary where the key/value pairs represent fields
		and their respective values.
		pos : The array index on which to add the value, for multi-value
		      items. If not specified, then the last element from the array is used.
		"""
		for (name, val) in values.iteritems() :
			self.appendItemValue (name, val, pos)
			
			
	def prettyPrint (self) :
		"""Helper function for outputing the current stored values
		"""
		
		print "\nID: " + str(self.id)
		for val in self.value :
			print "Fields: " + str (val.field_names)
			#print "Values: " + str (val.field_values)
