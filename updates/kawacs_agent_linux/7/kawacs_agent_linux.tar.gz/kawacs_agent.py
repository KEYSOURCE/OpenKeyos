#!/usr/bin/env python
#file statistics.py

"""Linux implementation of a Kawacs Agent

The Kawacs Agent will be regularily called from crontab, will connect
to the Kawacs server to see what information should be reported about
this machine (if any), will collect the information and send it.

The kawacs.ini file stores the settings for the application and for
communicating with the Kawacs server.

Most information to be collected and reported will be collected from
the XML output of omreport, which will be saved into a temporary XML
file for faster access.

Since the application will be usually run from crontab, there will be 
no output to stdout. A log file will be used instead. The name of the
log file and the amount of information to log is defined in kawacs.ini

The script can be invoked with the following parameters:
  -f    : Do a full update of Kawacs information
  -d    : Show output debug on stdout
  -b    : Report backup status

The current script (kawacs_agent.py) will also use the modules:
  - KawacsConfig    : Loads settings from kawacs.ini and initializes
                      various constants.
  - KawacsLib       : Defines useful functions and classes.
  - KawacsInfo      : Implements functions for extracting monitor
                      items data from the XML output of omreport.

Third party required packages:
  - SOAPpy  : http://pywebsvcs.sourceforge.net/ 
  - fpconst : http://research.warnes.net/projects/rzope/fpconst/

"""

import os
import sys
import urllib
import md5
from time import localtime

# Make sure the working dir is the same as the script location
work_dir = os.path.abspath(os.path.dirname(sys.argv[0])) 
os.chdir (work_dir)

sys.path.append ('./lib')
from KawacsLib import Computer, MonitorItem, MonitorItemValue
from KawacsLib import do_log, check_log_rotation, get_xml_doc, clear_dir

from KawacsConfig import CUSTOMER_ID, SOAP_URL, DEBUG_LEVEL
from KawacsConfig import MAC_ADDRESS, REPORTED_MAC_ADDRESS, PROFILE_ID, TYPE_ID, COMPUTER_ID, REMOTE_IP
from KawacsConfig import LOGFILE_NAME, MAX_LOG_SIZE, MSG_ERROR, MSG_TRACE, MSG_DEBUG
from KawacsConfig import VERSION, IFCONFIG, TAR, OMREPORT, DOWNLOAD_DIR, DOWNLOAD_FILE_PREFIX

import KawacsInfo
from KawacsInfo import LIBXML2_AVAILABLE, IDS_NEEDING_LIBXML2

check_log_rotation ()
do_log ('Start reporting.', MSG_TRACE)

# Check the parameters used in invocation
FULL_UPDATE = 0
SHOW_DEBUG = 0
REPORT_BACKUP = 0
if (sys.argv is not None) :
	FULL_UPDATE = ('-f' in sys.argv)
	SHOW_DEBUG = ('-d' in sys.argv)
	REPORT_BACKUP = ('-b' in sys.argv)

computer = Computer ()
if (REPORT_BACKUP) :
	# This is a request only to report the backup
	resp = {'requested_items':[1044], 'report_interval':1}
else:
	resp = computer.getNeededInfo (FULL_UPDATE, SHOW_DEBUG)

# The exit value from the program. Will be 1 if collecting has failed for any item
SYS_EXIT = 0

if ((resp['report_interval'] > 0) or (len(resp['requested_items']) > 0)) :
	
	# The server specified a positive update interval, so proceed with reporting
	if (len(resp['requested_items']) > 0) :
		if (DEBUG_LEVEL >= MSG_TRACE) :
			do_log ('Server requested items: '+str(resp['requested_items']))
		
		# Check if any of the requested IDs need omreport (and libxml2)
		omreport_needed = 0
		for id in resp['requested_items'] :
			id = int(id)
			if (id in IDS_NEEDING_LIBXML2) :
				omreport_needed = 1
				break
		
		# Start collecting the information, initialize the default XML DOM tree
		data = []
		doc = None
		if (omreport_needed) :
			if (LIBXML2_AVAILABLE and OMREPORT != '') :
				doc = get_xml_doc ()
			else :
				if (not LIBXML2_AVAILABLE) :
					if (SHOW_DEBUG) : print 'ERROR: libxml2 is not available'
					do_log ('Libxml2 is not available', MSG_ERROR)
				if (not OMREPORT) :
					if (SHOW_DEBUG) : print 'ERROR: omreport is not available'
					do_log ('Omreport is not available', MSG_ERROR)
		
		for id in resp['requested_items'] :
			id = int (id)

			if ((not id in IDS_NEEDING_LIBXML2) or \
			(id in IDS_NEEDING_LIBXML2 and LIBXML2_AVAILABLE and OMREPORT != '')) :
				
				# Get a reference to the needed function for collecting info
				func_name = 'collect_' + str(id)
				func = getattr (KawacsInfo, 'collect_'+str(id), None)
					
				if (id < 2000 or func is not None) :
					# Make sure to collect only automatic items
					do_log ('Collecting item: '+str(id), MSG_DEBUG)
					item = MonitorItem (id)
					collected_ok = 0
					
					if (func is not None) :
						try :
							collected_ok = func (item, doc);
						except :
							collected_ok = 0
							do_log ('Failed collecting item '+str(id)+'. '+str(sys.exc_info()[0])+' : '+str(sys.exc_info()[1]), MSG_ERROR)
							if (SHOW_DEBUG) : print 'ERROR: Failed collecting item '+str(id)+'. '+str(sys.exc_info()[0])+' : '+str(sys.exc_info()[1])
					else :
						do_log ('Unknown item/function: ' + func_name, MSG_ERROR)
					
					if (SHOW_DEBUG) : item.prettyPrint ()
					
					if (collected_ok == 1) : 
						data.append (item)
						if (SHOW_DEBUG) : print 'Item collected OK'
					else :
						SYS_EXIT = 1
						do_log ('Item '+str(id)+' was not collected OK', MSG_ERROR)
						if (SHOW_DEBUG) : print 'ERROR: Item '+str(id)+' was not collected OK'
				else :
					do_log ('Skipping item: '+str(id), MSG_DEBUG)
			else :
				do_log ('Skipping item: '+str(id)+', omreport and/or libxml2 not available', MSG_TRACE)
			
		# Send now the collected info to the Kawacs server
		if (len(data) > 0) :
			computer.sendCollectedData (data, SHOW_DEBUG)
		else :
			do_log ('No items to send', MSG_TRACE)
		
		
	else :
		do_log ('Server requested no items.', MSG_TRACE)

else :
	# The server specified a negative report interval,
	# which means either and auto-update request or a request to not report
	
	if ((resp['download'] is not None) and (len(resp['download']) > 0)) :
		# The server requested an auto-update
		
		download_url = resp['download'][0]['url']
		download_file = resp['download'][0]['zip_name']
		download_md5 = resp['download'][0]['md5_checksum']
		
		if (download_url != '' and download_url != 'http://' and download_file != '' and download_md5 != '') :
			# Download data specified OK
			do_log ('Server requested auto-update, URL: '+download_url, MSG_TRACE)
			download_file = DOWNLOAD_DIR + '/' + DOWNLOAD_FILE_PREFIX + download_file

			downloaded_ok = 0
			try :
				# Make sure the download dir is clean
				clear_dir (DOWNLOAD_DIR)
				
				# Download the file
				fp = urllib.urlopen (download_url)
				fw = open (download_file, 'w')
				info = fp.read ()
				while info : 
					fw.write (info)
					info = fp.read ()
				fw.close ()
				fp.close ()
				downloaded_ok = 1
			except :
				do_log ('Failed downloading update: ', MSG_ERROR)
				
			if (downloaded_ok == 1) :
				do_log ('Downloaded OK: '+download_file, MSG_TRACE)
				
				# Verify checksum
				file_content = open (download_file,'r').read()
				md5_obj = md5.new (file_content)
				md5_sum = md5_obj.hexdigest()
				
				if (md5_sum == download_md5) :
					do_log ('MD5 checksum verifies OK: '+md5_sum, MSG_TRACE)
					
					# Unpack the files
					res = os.system (TAR+' -xzf '+download_file+' --exclude *.ini')
					if (res == 0) :
						do_log ('Archive unpacked  OK', MSG_TRACE)
					else :
						do_log ('Failed unpacking archive: '+str(sys.exc_info()[0])+' : '+str(sys.exc_info()[1]), MSG_ERROR)

				else :
					do_log ('MD5 checksum error. Expected: '+download_md5+', got: '+md5_sum, MSG_ERROR)

		else :
			# Download info incomplete
			if (download_url == '' or download_url == 'http://') : do_log ('Download URL has not been specified', MSG_ERROR)
			if (download_file == '') : do_log ('The name of the download file has not been specified', MSG_ERROR)
			if (download_md5 == '') : do_log ('The MD5 checksum of the download file has not been specified', MSG_ERROR)
	else :
		do_log ('Server sent a response interval of 0, so there is nothing to do', MSG_TRACE)

do_log ('Finished reporting.', MSG_TRACE)

sys.exit (SYS_EXIT)
